function rectangle(height,width){
    this.height=height
    this.width=width

    return this.height*this.width
}

console.log(rectangle(10,20));