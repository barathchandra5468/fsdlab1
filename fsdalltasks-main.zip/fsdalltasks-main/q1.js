                                           // Question :1
console.log(a);
var a=10;
console.log(a);
a=30;
console.log(a);


//console.log(b);
let b=20;
console.log(b);
b=40;
console.log(b)

//console.log(c);
const c=50;
//c=60;
console.log(c);




var a=10;
var name="deva"
var istrue=true;
console.log(a+" "+name+" "+istrue);